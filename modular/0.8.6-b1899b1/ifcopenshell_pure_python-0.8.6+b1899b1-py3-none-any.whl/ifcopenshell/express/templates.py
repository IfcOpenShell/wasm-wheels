# IfcOpenShell - IFC toolkit and geometry engine
# Copyright (C) 2021 Thomas Krijnen <thomas@aecgeeks.com>
#
# This file is part of IfcOpenShell.
#
# IfcOpenShell is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# IfcOpenShell is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with IfcOpenShell.  If not, see <http://www.gnu.org/licenses/>.


header = """
#ifndef %(schema_name_upper)s_H
#define %(schema_name_upper)s_H

#include <string>
#include <vector>
#include <optional>

#include "../../ifcparse/ifc_parse_api.h"

#include "../../ifcparse/express.h"
#include "../../ifcparse/schema.h"
#include "../../ifcparse/exception.h"
#include "../../ifcparse/argument.h"

namespace ifcopenshell {
class file;
class spf_header;
} // namespace ifcopenshell

struct %(schema_name)s {

IFC_SCHEMA_API static const ifcopenshell::schema_definition& get_schema();

IFC_SCHEMA_API static void clear_schema();

static const char* const Identifier;

// Forward definitions
%(forward_definitions)s

%(declarations)s

%(class_definitions)s
};

#endif
"""

enum_header = """
#ifndef %(schema_name_upper)sENUM_H
#define %(schema_name_upper)sENUM_H

#include "../../ifcparse/ifc_parse_api.h"

#include <string>
#include <optional>

#endif
"""

lb_header = """"""

implementation = """
#include "../../ifcparse/schemas/%(schema_name)s.h"
#include "../../ifcparse/schema.h"
#include "../../ifcparse/exception.h"
#include "../../ifcparse/file.h"

#include <map>

const char* const %(schema_name)s::Identifier = "%(schema_name_upper)s";

using namespace ifcopenshell;

// External definitions
%(external_definitions)s

%(enumeration_functions)s

%(simple_type_impl)s

%(entity_implementations)s
"""

lb_implementation = """"""

entity_descriptor = """    current = entity_descriptor_map[Type::%(type)s] = new IfcEntityDescriptor(Type::%(type)s,%(parent_statement)s);
%(entity_descriptor_attributes)s"""

entity_descriptor_parent = "entity_descriptor_map.find(Type::%(type)s)->second"
entity_descriptor_attribute_without_entity = '    current->add("%(name)s",%(optional)s,%(type)s);'
entity_descriptor_attribute_with_entity = '    current->add("%(name)s",%(optional)s,%(type)s,Type::%(entity_name)s);'

enumeration_descriptor = """    values.clear(); values.reserve(128);
%(enumeration_descriptor_values)s
    enumeration_descriptor_map[Type::%(type)s] = new IfcEnumerationDescriptor(Type::%(type)s, values);"""

enumeration_descriptor_value = '    values.push_back("%(name)s");'

derived_field_statement = "    {std::set<int> idxs; %(statements)sderived_map[Type::%(type)s] = idxs;}"
derived_field_statement_attrs = "idxs.insert(%d); "

simpletype = """%(documentation)s
class IFC_SCHEMA_API %(name)s : public %(superclass)s {
public:
    using %(superclass)s::%(superclass_2)s;

    static const ifcopenshell::type_declaration& Class();
    %(name)s initialize(%(type)s v);
    operator %(type)s() const;
};
"""

simpletype_impl_comment = "// Function implementations for %(name)s"
simpletype_impl_argument_type = 'if (i == 0) { return %(attr_type)s; } else { throw ifcopenshell::attribute_out_of_range_exception("Argument index out of range"); }'
simpletype_impl_argument = "return get_attribute_value(i);"
simpletype_impl_is_with_supertype = "return v == %(class_name)s_type || %(superclass)s::is(v);"
simpletype_impl_is_without_supertype = "return v == %(class_name)s_type;"
simpletype_impl_type = "return *((ifcopenshell::type_declaration*)%(schema_name_upper)s_types[%(index_in_schema)d]);"
simpletype_impl_class = "return *((ifcopenshell::type_declaration*)%(schema_name_upper)s_types[%(index_in_schema)d]);"
simpletype_impl_explicit_constructor = "data_ = e;"
simpletype_impl_constructor = (
    "data_ = new const std::weak_ptr<instance_data>&(%(schema_name_upper)s_types[%(index_in_schema)d]); set_attribute_value(0, v);"
)
simpletype_impl_constructor_templated = "data_ = new const std::weak_ptr<instance_data>&(%(schema_name_upper)s_types[%(index_in_schema)d]); set_attribute_value(0, cast_vector<express::Base>(v));"
simpletype_impl_cast = "return get_attribute_value(0);"
simpletype_impl_cast_templated = "std::vector<express::Base> es = get_attribute_value(0); return cast_vector<%(underlying_type)s>(es);"

simpletype_impl_declaration = "return *((ifcopenshell::type_declaration*)%(schema_name_upper)s_types[%(index_in_schema)d]);"

select = """%(documentation)s
class IFC_SCHEMA_API %(name)s : public express::Select {
public:
    using express::Select::Select;

    static const ifcopenshell::select_type& Class();
%(template_items)s
%(cast_functions)s
};
"""

select_list_item = """    // let's just use the as<>() from Base instead directly...
    // template<class T, std::enable_if_t<std::is_same_v<T, %(item_name)s>, int> = 0>
    // %(item_name)s as() const { return express::Base::as<%(item_name)s>(); }
"""

select_cast_function = """    %(name)s(const %(item_name)s& c) : express::Select(c) {};
"""

enumeration = """%(documentation)s
class IFC_SCHEMA_API %(name)s : public express::DeclaredType {
public:
    using express::DeclaredType::DeclaredType;

    typedef enum {%(values)s} Value;
    static const char* ToString(Value v);
    static Value FromString(const std::string& s);

    static const ifcopenshell::enumeration_type& Class();
    %(name)s initialize(Value v);
    %(name)s initialize(const std::string& v);
    operator Value() const;
};
"""

entity = """%(documentation)s
class IFC_SCHEMA_API %(name)s : public %(superclass)s {
public:
    using %(superclass)s::%(superclass_2)s;

%(attributes)s    %(inverse)s
    static const ifcopenshell::entity& Class();
    %(name)s initialize(%(constructor_arguments)s);
};
"""

select_function = """
const ifcopenshell::select_type& %(schema_name)s::%(name)s::Class() { return *((ifcopenshell::select_type*)%(schema_name_upper)s_types[%(index_in_schema)d]); }
"""

enumeration_function = """
// const ifcopenshell::enumeration_type& %(schema_name)s::%(name)s::declaration() const { return *((ifcopenshell::enumeration_type*)%(schema_name_upper)s_types[%(index_in_schema)d]); }
const ifcopenshell::enumeration_type& %(schema_name)s::%(name)s::Class() { return *((ifcopenshell::enumeration_type*)%(schema_name_upper)s_types[%(index_in_schema)d]); }

/*
%(schema_name)s::%(name)s::%(name)s(const std::weak_ptr<instance_data>& e)
    : express::DeclaredType(e)
{}

%(schema_name)s::%(name)s::%(name)s(Value v) {
    set_attribute_value(0, enumeration_reference(&Class(), static_cast<size_t>(v)));
}

%(schema_name)s::%(name)s::%(name)s(const std::string& v) {
    set_attribute_value(0, enumeration_reference(&Class(), Class().lookup_enum_offset(v)));
}
*/

const char* %(schema_name)s::%(name)s::ToString(Value v) {
    return %(schema_name)s::%(name)s::%(name)s::Class().lookup_enum_value((size_t)v);
}

%(schema_name)s::%(name)s::Value %(schema_name)s::%(name)s::FromString(const std::string& s) {
    return (%(schema_name)s::%(name)s::Value) %(schema_name)s::%(name)s::%(name)s::Class().lookup_enum_offset(s);
}

%(schema_name)s::%(name)s::operator %(schema_name)s::%(name)s::Value() const {
    return (%(schema_name)s::%(name)s::Value) ((enumeration_reference) get_attribute_value(0)).index();
}
"""

entity_implementation = """// Function implementations for %(name)s
%(attributes)s
%(inverse)s
const ifcopenshell::entity& %(schema_name)s::%(name)s::Class() { return *((ifcopenshell::entity*)%(schema_name_upper)s_types[%(index_in_schema)d]); }
%(schema_name)s::%(name)s %(schema_name)s::%(name)s::initialize(%(constructor_arguments)s) { %(constructor_implementation)s; return *this; }
"""

# data_ = e; 
# data_ = new const std::weak_ptr<instance_data>&(%(schema_name_upper)s_types[%(index_in_schema)d]);

optional_attribute_description = "/// Whether the optional attribute %s is defined for this %s"

function = "%(return_type)s %(schema_name)s::%(class_name)s::%(name)s(%(arguments)s) { %(body)s }"
const_function = "%(return_type)s %(schema_name)s::%(class_name)s::%(name)s(%(arguments)s) const { %(body)s }"
constructor = "%(schema_name)s::%(class_name)s::%(class_name)s(%(arguments)s) { %(body)s }"
initialize_single_initlist = (
    "%(schema_name)s::%(class_name)s %(schema_name)s::%(class_name)s::initialize(%(arguments)s) { %(body)s; return *this; }"
)
cast_function = "%(schema_name)s::%(class_name)s::operator %(return_type)s() const { %(body)s }"

array_type = "std::vector< %(instance_type)s > /*[%(lower)s:%(upper)s]*/"
nested_array_type = "std::vector< std::vector< %(instance_type)s > >"
list_type = "std::vector< %(instance_type)s >"
list_list_type = "std::vector< std::vector< %(instance_type)s > >"
untyped_list = "aggregate_of_instance::ptr"
inverse_attr = "std::vector< %(entity)s > %(name)s() const; // INVERSE %(entity)s::%(attribute)s"

enum_from_string_stmt = '    if (s == "%(value)s") return ::%(schema_name)s::%(name)s::%(short_name)s_%(value)s;'

schema_entity_stmt = "        case Type::%(name)s: return new %(name)s(e); break;"
string_map_statement = '    string_map["%(uppercase_name)s"%(padding)s] = Type::%(name)s;'
parent_type_stmt = "    if(v==%(name)s%(padding)s) { return %(parent)s; }"

parent_type_test = " || %s::is(v)"

optional_attr_stmt = "return !get_attribute_value(%(index)d).isNull();"

get_attr_stmt = "%(null_check)s %(non_optional_type)s v = get_attribute_value(%(index)d); return v;"
get_attr_stmt_enum = "%(null_check)s return %(non_optional_type)s::FromString(get_attribute_value(%(index)d));"
get_attr_stmt_entity = "%(null_check)s return ((express::Base)(get_attribute_value(%(index)d))).as<%(non_optional_type_no_pointer)s>();"
get_attr_stmt_array = "%(null_check)s std::vector<express::Base> es = get_attribute_value(%(index)d); return cast_vector<%(list_instance_type)s>(es);"
get_attr_stmt_nested_array = "%(null_check)s std::vector<std::vector<express::Base>> es = get_attribute_value(%(index)d); return cast_vector<%(list_instance_type)s>(es);"

get_inverse = "return cast_vector<%(type)s>(file()->get_inverse(data()->id(), %(schema_name_upper)s_types[%(type_index)d], %(index)d));"

set_attr_stmt = (
    "%(check_optional_set_begin)sset_attribute_value(%(index)d, %(star_if_optional)sv);%(check_optional_set_else)sunset_attribute_value(%(index)d);%(check_optional_set_end)s"
)
set_attr_instance = (
    "%(check_optional_set_begin)sset_attribute_value(%(index)d, v);%(check_optional_set_else)sunset_attribute_value(%(index)d);%(check_optional_set_end)s"
)
set_attr_stmt_enum =  "%(check_optional_set_begin)sset_attribute_value(%(index)d, enumeration_reference(&%(non_optional_type)s::Class(), (size_t) %(star_if_optional)sv));%(check_optional_set_else)sunset_attribute_value(%(index)d);%(check_optional_set_end)s"
set_attr_stmt_array = (
    "%(check_optional_set_begin)sset_attribute_value(%(index)d, cast_vector<express::Base>(%(star_if_optional)sv));%(check_optional_set_else)sunset_attribute_value(%(index)d);%(check_optional_set_end)s"
)
set_attr_stmt_nested_array = (
    "%(check_optional_set_begin)sset_attribute_value(%(index)d, cast_vector<express::Base>(%(star_if_optional)sv));%(check_optional_set_else)sunset_attribute_value(%(index)d);%(check_optional_set_end)s"
)

constructor_stmt = (
    "set_attribute_value(%(index)d, (%(name)s));"
)
constructor_stmt_enum = (
    "set_attribute_value(%(index)d, (enumeration_reference(&%(type)s::Class(),(size_t)%(name)s)));"
)
constructor_stmt_array = (
    "set_attribute_value(%(index)d, cast_vector<express::Base>(%(name)s));"
)
constructor_stmt_derived = (
    ""
)
constructor_stmt_instance = (
    "set_attribute_value(%(index)d, %(name)s);"
)

constructor_stmt_optional = " if (%(name)s) {%(stmt)s }"

inverse_implementation = '    inverse_map[Type::%(type)s].insert(std::make_pair("%(name)s", std::make_pair(Type::%(related_type)s, %(index)d)));'


def multi_line_comment(li):
    return ("/// %s" % ("\n/// ".join(li))) if len(li) else ""


